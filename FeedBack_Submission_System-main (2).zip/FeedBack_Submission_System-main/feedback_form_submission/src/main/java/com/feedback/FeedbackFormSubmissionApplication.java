package com.feedback;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FeedbackFormSubmissionApplication {

	public static void main(String[] args) {
		SpringApplication.run(FeedbackFormSubmissionApplication.class, args);
	}

}
