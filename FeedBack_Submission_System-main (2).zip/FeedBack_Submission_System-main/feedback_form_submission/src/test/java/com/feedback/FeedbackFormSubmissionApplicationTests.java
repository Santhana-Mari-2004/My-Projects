package com.feedback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeedbackFormSubmissionApplicationTests {

	@Test
	void contextLoads() {
	}

}
